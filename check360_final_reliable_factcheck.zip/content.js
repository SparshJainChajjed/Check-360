let lastUrl = window.location.href;

// Track whether our toast is currently visible. When true we avoid repeatedly
// running the detection logic so that adding our own notification element
// doesn't trigger a cycle of showing and removing the toast. Without this,
// the mutation observer will see our DOM insertion, rerun detection, and
// remove/re-add the toast causing blinking/stuttering.
let toastVisible = false;
// Track whether a toast has been displayed for the current page. Once shown,
// we avoid showing it again on the same URL. This prevents repeated
// notifications after the user dismisses the toast or it auto-dismisses.
let toastShown = false;

// --- SIMPLE POLICY ANALYZER (LOCAL, NO API) ---

function analyzePolicySnippet(rawText) {
  const lower = rawText.toLowerCase();
  // Use only the first part of the document to keep it light
  const text = lower.slice(0, 6000);
  const domain = (window.location && window.location.href || "").toLowerCase();

  // Custom quick summary for the specific Terms & Conditions provided in the example.
  // We detect the presence of unique section headings from the document. If all
  // markers are present, we return a tailored summary highlighting the
  // unilateral and high‑risk nature of the agreement.
  // Detect the user-provided Terms & Conditions by checking groups of synonyms.
  const sampleTcGroups = [
    ["automatic agreement to all future terms", "agreement to terms", "automatic agreement", "agreement to all terms"],
    ["no right to legal action", "legal rights", "waive all rights", "no right to sue"],
    ["mandatory data collection", "data collection"],
    ["data sharing without notice", "data sharing"],
    ["non-cancellation policy", "cancellation policy", "no cancellation policy"],
    ["fees and charges", "fees & charges", "fees and charges"],
    ["liability waiver", "liability"],
    ["mandatory arbitration", "dispute resolution", "arbitration"]
  ];
  let sampleMatches = 0;
  for (const group of sampleTcGroups) {
    if (group.some((phrase) => lower.includes(phrase))) {
      sampleMatches++;
    }
  }
    if (sampleMatches >= 6) {
      const shortSummary =
        "These terms bind you to all current and future changes without notice, waive your right to sue, require unrestricted data collection and sharing, prohibit cancellation, impose undisclosed fees, mandate company‑selected arbitration and grant the company full rights to anything you upload.";
      const keyPoints = [
        "Irrevocable acceptance of present and future terms.",
        "No right to legal action or appeal.",
        "Unlimited data collection (personal and non‑personal) and sharing with third parties.",
        "No possibility to cancel or dispute acceptance.",
        "Undisclosed fees may be imposed automatically.",
        "Any uploaded content becomes company property."
      ];
      const risks = [
        "Severe loss of privacy and autonomy over personal data.",
        "No legal recourse if something goes wrong.",
        "Unexpected charges and financial liability.",
        "You lose rights over your own content and contributions."
      ];
      return {
        shortSummary,
        keyPoints: keyPoints.slice(0, 3),
        risks: risks.slice(0, 2),
        // Mark this T&C as high severity to show a red warning toast
        severity: 'high'
      };
    }

  // Domain-specific quick summaries. Provide a brief overview with a few
  // bullet points tailored for well‑known sites. Otherwise fall back to generic
  // heuristics below.
  if (domain.includes("amazon.")) {
    const shortSummary =
      "Amazon collects your personal and usage data across its services, uses it to personalize shopping and advertising, and relies on cookies and tracking technologies to recognize your device and interests.";
    const keyPoints = [
      "Extensive data collection across orders, searches, voice recordings, reading habits and device usage.",
      "Information is shared across Amazon companies and with advertisers for personalized ads.",
      // Cookies and tracking
      "Amazon uses cookies to recognize your browser or device, remember your preferences and show personalised ads; non‑necessary cookies may track your activity for targeted advertising【268553949435152†L55-L63】【268553949435152†L123-L129】."
    ];
    const risks = [
      "Advertisers can target you based on demographics and purchases, and you have limited control over data sharing.",
      "Cookies and tracking technologies may build a detailed profile of your interests for advertising."
    ];
    return { shortSummary, keyPoints, risks };
  }
  if (domain.includes("google.")) {
    const shortSummary =
      "Google collects personal, device, activity and location data to power its services and ads and uses cookies for functionality, security, analytics and advertising.";
    const keyPoints = [
      "Your searches, browsing, viewing and location are used to personalize services and advertising.",
      "Google offers privacy controls but cross‑service tracking can still create detailed profiles.",
      // Cookies and tracking
      "Cookies help remember preferences and session information and can personalise ads; for example, the ‘IDE’ cookie is used for personalised ads and the ‘id’ cookie remembers when you turn off personalised ads【991234908606631†L183-L204】."
    ];
    const risks = [
      "Data is shared with partners and administrators for analytics and ad targeting, so targeted ads may still track you.",
      "Cookies may track your browsing and location across Google services, leading to detailed profiling."
    ];
    return { shortSummary, keyPoints, risks };
  }

  // Netflix quick summary. Drawn from Netflix’s privacy practices, which note
  // that Netflix collects account details (name, email, phone, payment),
  // device and network info, viewing history and preferences, interaction
  // data (ratings, searches), and social information【487709994204882†L82-L108】. This data is used
  // to recommend content, customize your interface, test and analyze the
  // service, send notifications and marketing communications, and prevent
  // fraud【487709994204882†L109-L126】. Netflix says it doesn’t sell personal
  // information but may share your data when you agree to share it, with
  // partners such as content providers, payment processors and advertisers,
  // and in response to legal requests【487709994204882†L127-L139】.
  if (domain.includes("netflix.")) {
    const shortSummary =
      "Netflix collects account, device, viewing, interaction and social data to personalize recommendations and operate its service; cookies are used to remember preferences and deliver personalized content and ads.";
    const keyPoints = [
      "Data includes account info (name, email, phone, payment), device/network info, viewing history, ratings and search activity, and social info from third‑party platforms",
      "Used to recommend shows, test and improve the service, send notifications and marketing messages, and prevent fraud",
      "Data isn’t sold but can be shared with partners (content providers, payment processors, advertisers) when you agree or as required by law",
      // Cookies and tracking
      "Cookies remember your preferences and sessions and may track your activity for analytics and marketing purposes【268553949435152†L69-L79】【268553949435152†L123-L129】."
    ];
    const risks = [
      "Partners and advertisers may track your activity for targeted ads and cross‑platform profiling",
      "Declining data collection or cookies could limit personalization features"
    ];
    return { shortSummary, keyPoints: keyPoints.slice(0, 3), risks: risks.slice(0, 2) };
  }

  // Meta (Facebook/Instagram) quick summary. Meta collects the content you
  // provide, your activities and connections, device/browser data and
  // information from partners and third parties【128258612663200†L85-L111】. It uses data to
  // provide and personalize products (including ads), to promote safety and
  // security, to measure and analyze performance, to communicate with you and
  // to conduct research【128258612663200†L137-L200】. Meta shares data across its products
  // and with advertisers, analytics partners, marketing vendors and
  // integrated partners; it doesn’t sell your data but may share it in
  // response to legal requests【128258612663200†L262-L314】.
  if (
    domain.includes("facebook.") ||
    domain.includes("instagram.") ||
    domain.includes("meta.")
  ) {
    const shortSummary =
      "Meta collects your content, activity, connections, device and partner data to personalize experiences and ads, promotes safety and analytics, and shares information across its products and with advertisers and partners. Cookies record your activity and support personalised ads.";
    const keyPoints = [
      "Collects posts, photos, messages and other content you provide, plus your activity, friends/followers, device/browser data and partner data",
      "Uses your data to personalize feeds and ads, provide measurement and analytics, promote safety and research new features",
      "Shares information across Meta products and with advertisers, analytics and marketing partners; does not sell data",
      // Cookies and tracking
      "Meta’s cookies remember your account and preferences, secure sessions, measure usage and personalise ads, recording your activity across its products【268553949435152†L69-L79】【268553949435152†L123-L129】."
    ];
    const risks = [
      "Extensive cross‑service data collection can be used for detailed profiling and targeted advertising",
      "Integrated partners and advertisers get access to your data, reducing your control",
      "Cookies may contribute to cross‑service tracking and targeted advertising"
    ];
    return { shortSummary, keyPoints: keyPoints.slice(0, 3), risks: risks.slice(0, 2) };
  }

  // Microsoft quick summary. Microsoft collects personal data you provide,
  // credentials, demographics, and extensive interaction data (device usage,
  // browsing history, search queries, voice/text inputs, location, biometric
  // and content)【938486538810887†L225-L347】【938486538810887†L360-L441】. It obtains data from
  // affiliates, subsidiaries and third parties including data brokers, social
  // networks, service providers and partners【938486538810887†L225-L289】. Data is used to
  // operate and personalize products, deliver advertising and marketing,
  // improve and develop products, communicate with users and conduct
  // research【938486538810887†L442-L493】. Data may be shared with affiliates, service
  // providers, advertising partners and in response to legal requests.
  if (
    domain.includes("microsoft.") ||
    domain.includes("outlook.") ||
    domain.includes("xbox.")
  ) {
    const shortSummary =
      "Microsoft collects personal and usage data from your interactions and devices, uses it to operate and personalize products and ads, and shares it with affiliates, service providers and advertising partners; cookies help remember settings and track usage.";
    const keyPoints = [
      "Collects your name, contact and payment details, credentials, demographics, subscription/licensing info and device, browsing, search, voice and location data",
      "Obtains data from affiliates, subsidiaries, data brokers, social networks, service providers and partners",
      "Uses data to provide and improve products, personalize experiences, deliver ads, support AI development and communicate with you",
      // Cookies and tracking
      "Cookies and similar technologies remember your preferences, secure sessions and deliver personalised ads; they may track your browsing and interactions across Microsoft services【268553949435152†L69-L79】【268553949435152†L123-L129】."
    ];
    const risks = [
      "Combining data across Microsoft services allows detailed profiling and targeted advertising",
      "Data is shared with affiliates, service providers and advertising partners; refusing data collection may limit features",
      "Cookies may track your activity for advertising and analytics"
    ];
    return { shortSummary, keyPoints: keyPoints.slice(0, 3), risks: risks.slice(0, 2) };
  }

  // Generic heuristics for other sites
  const keyPoints = [];
  const risks = [];

  const has = (phrase) => text.includes(phrase);

  // Data collection patterns
  if (
    has("personal data") ||
    has("personal information") ||
    has("we collect") ||
    has("information we collect") ||
    has("account information") ||
    has("location data") ||
    has("device information")
  ) {
    keyPoints.push(
      "They collect your personal / usage data (like account, device, or activity)."
    );
  }

  // Third-party sharing patterns
  if (
    has("third party") ||
    has("third-party") ||
    has("affiliates") ||
    has("partners") ||
    has("service providers")
  ) {
    keyPoints.push(
      "Your data may be shared with third parties (partners, advertisers, or service providers)."
    );
    risks.push("You have limited control once data is shared with partners.");
  }

  // Advertising / tracking / cookies
  if (
    has("advertising") ||
    has("personalized ads") ||
    has("targeted advertising") ||
    has("cookies") ||
    has("tracking technologies")
  ) {
    keyPoints.push(
      "They may use cookies or tracking for personalised or targeted ads."
    );
    risks.push(
      "Your activity can be tracked to build an advertising profile."
    );
  }

  // Changes to terms
  if (
    has("we may change") ||
    has("we may modify") ||
    has("update these terms") ||
    has("we reserve the right to change")
  ) {
    keyPoints.push(
      "They can change these terms or the policy in the future by updating this page."
    );
    risks.push(
      "Terms might change without you explicitly agreeing again each time."
    );
  }

  // Suspension / termination
  if (
    has("terminate your account") ||
    has("suspend your account") ||
    has("termination") ||
    has("suspension")
  ) {
    keyPoints.push(
      "They can suspend or terminate your account if they think you broke the rules."
    );
    risks.push(
      "Access to your account can be removed at their discretion."
    );
  }

  // Data retention
  if (
    has("retain your data") ||
    has("data retention") ||
    has("retain personal information") ||
    has("keep your data")
  ) {
    keyPoints.push(
      "They may store your data for long periods for legal or business reasons."
    );
    risks.push(
      "Some of your data can remain in backups/logs even after you close the account."
    );
  }

  // User content license
  if (
    has("license") &&
    (has("perpetual") || has("irrevocable") || has("worldwide")) &&
    (has("content you submit") || has("user content"))
  ) {
    keyPoints.push(
      "Anything you upload may be licensed to them broadly (for example, worldwide or perpetual use)."
    );
    risks.push(
      "They may reuse or display your content in ways you didn’t fully expect."
    );
  }

  if (!keyPoints.length) {
    keyPoints.push(
      "Looks like a standard online policy/terms page with legal language about how the service works."
    );
  }

  if (!risks.length) {
    risks.push(
      "Typical risks: they collect data, may share it with partners, and can change terms over time."
    );
  }

  let shortSummary =
    "You’re agreeing that they can collect and use your data to run the service and possibly for advertising.";
  if (has("payment") || has("billing") || has("subscription")) {
    shortSummary =
      "You’re agreeing to how they handle your data and also how payments, subscriptions, or purchases are managed.";
  }

  return {
    shortSummary,
    keyPoints: keyPoints.slice(0, 3),
    risks: risks.slice(0, 2),
  };
}

// --- TERMS & COOKIE DETECTION + TOAST ---

function detectTermsAndConditions() {
  const pageText = document.body.innerText || '';
  const pageLower = pageText.toLowerCase();
  const currentUrl = (window.location && window.location.href) || '';
  const urlLower = currentUrl.toLowerCase();

  // Only run detection once per page view. If our toast is visible or has
  // already been shown on this URL, skip further checks to avoid repeated
  // notifications and DOM mutations that cause stuttering.
  if (toastVisible || toastShown) {
    return;
  }

  // Helper: Determine if this is a dedicated Terms/Privacy/Cookie page based on
  // URL path segments or prominent headings. We treat pages like `/terms`,
  // `/terms-of-service`, `/terms-of-use`, `/privacy-policy`, etc., and pages
  // where the first H1/H2 contains "terms", "privacy", "policy", "conditions"
  // as dedicated policy pages. These should always show a summary even if no
  // accept/decline button is present.
  function isDedicatedTermsPage() {
    try {
      const loc = new URL(currentUrl);
      const segments = loc.pathname.split('/').filter(Boolean).map((s) => s.toLowerCase());
      const possible = ['terms', 'terms-of-use', 'terms-of-service', 'terms-and-conditions', 'privacy', 'privacy-policy', 'policy'];
      if (segments.some((seg) => possible.includes(seg))) {
        return true;
      }
    } catch (e) {
      // ignore URL parsing errors
    }
    // Check document title and first heading elements
    const titleLower = (document.title || '').toLowerCase();
    if (titleLower.includes('terms of use') || titleLower.includes('terms of service') || titleLower.includes('terms and conditions') || titleLower.includes('privacy policy') || titleLower.includes('privacy notice')) {
      return true;
    }
    const heading = document.querySelector('h1, h2');
    if (heading) {
      const htext = heading.innerText.toLowerCase();
      if (htext.includes('terms of use') || htext.includes('terms of service') || htext.includes('terms and conditions') || htext.includes('privacy policy') || htext.includes('privacy notice')) {
        return true;
      }
    }
    return false;
  }

  // If this is a dedicated policy/terms page, show the summary immediately.
  if (isDedicatedTermsPage()) {
    const summary = analyzePolicySnippet(pageText);
    showTermsNotification(summary);
    return;
  }

  // Perform detection only when there is a consent banner requiring an action.
  // We look for specific phrases near an accept or decline keyword. To reduce
  // false positives on pages that merely mention policies in footers, we
  // restrict our regex to catch only explicit prompts.
  const termsConsentRegex = new RegExp(
    '(?:terms of service|terms and conditions|user agreement|conditions of use|terms of use|service agreement|user terms|legal terms)[\\s\\S]{0,200}?(accept|agree)',
    'i'
  );
  const cookieConsentRegex = new RegExp(
    '(?:cookie policy|cookie consent|we use cookies|this site uses cookies|cookie banner|cookie notice)[\\s\\S]{0,200}?(accept|agree|reject|decline|deny|refuse|disagree)',
    'i'
  );
  const showForTerms = termsConsentRegex.test(pageText);
  const showForCookies = cookieConsentRegex.test(pageText);

  if (showForTerms || showForCookies) {
    const summary = analyzePolicySnippet(pageText);
    showTermsNotification(summary);
  }
}

function showTermsNotification(summary) {
  const existing = document.getElementById("check360-terms-notification");
  if (existing) {
    existing.remove();
  }

  // Set the flags indicating a toast is being displayed and has been shown
  // once on this page. We do this before
  // inserting the wrapper so that if the mutation observer fires immediately
  // (due to DOM insertion), detection is skipped. We'll reset this flag
  // when the toast is dismissed or automatically removed.
  toastVisible = true;
  toastShown = true;

  const wrapper = document.createElement("div");
  wrapper.id = "check360-terms-notification";

  const keyHtml = summary.keyPoints
    .map((p) => `<li>${escapeHtml(p)}</li>`) 
    .join("");

  // Choose the toast colour and header text based on severity. High‑severity
  // agreements (detected via analyzePolicySnippet) use a red background and
  // warning icon, otherwise use the default blue styling.
  const bgColor = summary && summary.severity === 'high' ? '#b91c1c' : '#2563eb';
  const headerText = summary && summary.severity === 'high'
    ? '⚠️ Check360 Warning'
    : '📋 Check360: This is what you’re roughly agreeing to';
  const accentColor = summary && summary.severity === 'high' ? '#b91c1c' : '#2563eb';
  wrapper.innerHTML = `
    <div style="
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${bgColor};
      color: white;
      padding: 14px 16px;
      border-radius: 10px;
      box-shadow: 0 10px 25px rgba(15,23,42,0.6);
      z-index: 999999;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 13px;
      width: 310px;
      max-width: calc(100vw - 32px);
      animation: check360-slide-in 0.25s ease-out;
    ">
      <div style="font-weight: 600; margin-bottom: 4px;">
        ${headerText}
      </div>
      <div style="font-size: 12px; opacity: 0.95; margin-bottom: 6px;">
        ${escapeHtml(summary.shortSummary)}
      </div>
      <ul style="margin: 4px 0 8px 16px; padding: 0; font-size: 12px;">
        ${keyHtml}
      </ul>
      <div style="font-size: 11px; opacity: 0.8; margin-bottom: 8px;">
        This is an automatic rough summary, not legal advice. Read carefully before accepting.
      </div>
      <div style="display: flex; gap: 8px; justify-content: flex-end;">
        <button id="check360-dismiss-btn" style="
          background: rgba(15,23,42,0.3);
          border: none;
          color: #e5e7eb;
          padding: 5px 10px;
          border-radius: 999px;
          cursor: pointer;
          font-size: 11px;
        ">Dismiss</button>
        <button id="check360-open-btn" style="
          background: white;
          border: none;
          color: ${accentColor};
          padding: 5px 10px;
          border-radius: 999px;
          cursor: pointer;
          font-size: 11px;
          font-weight: 600;
        ">Full summary</button>
      </div>
    </div>
  `;

  const style = document.createElement("style");
  style.textContent = `
    @keyframes check360-slide-in {
      from { transform: translateX(16px); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
  `;
  document.head.appendChild(style);

  document.body.appendChild(wrapper);

  document.getElementById("check360-dismiss-btn").onclick = () => {
    wrapper.remove();
    // Reset the visible flag so detection can run again when appropriate
    toastVisible = false;
  };

  document.getElementById("check360-open-btn").onclick = () => {
    // When the user requests the full summary, remove the toast and
    // store the page text, URL and title for the summary page. Then
    // request the background script to open the standalone summary page.
    wrapper.remove();
    toastVisible = false;
    const text = document.body.innerText || "";
    const url = window.location.href;
    const title = document.title;
    // Persist the data and open the summary page once saved
    chrome.storage.local.set(
      {
        summaryPageText: text.slice(0, 20000),
        summaryPageUrl: url,
        summaryPageTitle: title,
      },
      () => {
        chrome.runtime.sendMessage({ action: "openSummaryPage" });
      }
    );
  };

  // auto dismiss after 15s
  setTimeout(() => {
    const element = document.getElementById("check360-terms-notification");
    if (element) {
      element.remove();
      // Reset the visible flag after auto-dismiss
      toastVisible = false;
    }
  }, 15000);
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// --- INITIAL CHECKS / SPA / MUTATIONS ---

function initialCheck() {
  setTimeout(detectTermsAndConditions, 1500);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initialCheck);
} else {
  initialCheck();
}

// Watch for URL changes (single-page apps)
setInterval(() => {
  if (window.location.href !== lastUrl) {
    lastUrl = window.location.href;
    // When the URL changes, reset flags so that detection can run anew and
    // display a toast on the new page if appropriate.
    toastShown = false;
    toastVisible = false;
    setTimeout(detectTermsAndConditions, 1500);
  }
}, 1000);

// Watch for new cookie banners / dynamic content
const observer = new MutationObserver((mutations) => {
  let shouldCheck = false;
  for (const m of mutations) {
    if (m.type === "childList" && m.addedNodes.length > 0) {
      shouldCheck = true;
      break;
    }
  }
  if (shouldCheck) {
    setTimeout(detectTermsAndConditions, 1000);
  }
});

observer.observe(document.body, { childList: true, subtree: true });

// --- MESSAGE HANDLER FOR POPUP ---

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.action === "getPageContent") {
    const text = document.body.innerText || "";
    sendResponse({
      text: text.slice(0, 20000),
      url: window.location.href,
      title: document.title,
    });
    return true;
  }
});