document.addEventListener("DOMContentLoaded", () => {
  const tabs = document.querySelectorAll(".tab-btn");
  const contents = document.querySelectorAll(".tab-content");
  const factBtn = document.getElementById("checkBtn");
  const policyBtn = document.getElementById("simplifyBtn");
  const factResult = document.getElementById("factResult");
  const policyResult = document.getElementById("policyResult");

  // Language selector elements for policy summary
  const policyLanguageWrapper = document.getElementById("policy-language-wrapper");
  const policyLanguageSelect = document.getElementById("policy-language-select");
  // Store the original (English) policy summary so it can be re-rendered or translated
  let currentPolicySummary = null;

  // Translation helper: Use Google's unofficial translate API to translate text
  async function translateText(text, targetLang) {
    try {
      const url =
        'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=' +
        encodeURIComponent(targetLang) +
        '&dt=t&q=' +
        encodeURIComponent(text);
      const res = await fetch(url);
      const data = await res.json();
      const translated = data[0].map((item) => item[0]).join('');
      return translated;
    } catch (e) {
      console.error('Translation failed', e);
      return text;
    }
  }

  // When the user changes the language, translate the current policy summary
  if (policyLanguageSelect) {
    policyLanguageSelect.addEventListener('change', async () => {
      if (!currentPolicySummary) return;
      const lang = policyLanguageSelect.value;
      if (lang === 'en') {
        renderPolicyResult(currentPolicySummary);
      } else {
        policyResult.innerHTML = 'Translating...';
        // Deep copy to avoid mutating original
        const summaryCopy = JSON.parse(JSON.stringify(currentPolicySummary));
        try {
          summaryCopy.shortSummary = await translateText(summaryCopy.shortSummary, lang);
          summaryCopy.fullSummary = await translateText(summaryCopy.fullSummary, lang);
          for (let i = 0; i < summaryCopy.keyPoints.length; i++) {
            summaryCopy.keyPoints[i] = await translateText(summaryCopy.keyPoints[i], lang);
          }
          for (let i = 0; i < summaryCopy.risks.length; i++) {
            summaryCopy.risks[i] = await translateText(summaryCopy.risks[i], lang);
          }
          renderPolicyResult(summaryCopy);
        } catch (e) {
          console.error('Translation error', e);
          renderPolicyResult(currentPolicySummary);
        }
      }
    });
  }

  // Tab switching
  tabs.forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.tab;

      tabs.forEach((b) => b.classList.remove("active"));
      contents.forEach((c) => c.classList.add("hidden"));

      btn.classList.add("active");
      document.getElementById(target).classList.remove("hidden");
    });
  });

  // If content script asked for Policy tab, auto-open it when popup opens
  chrome.storage.local.get("openPolicyTab", (data) => {
    if (data.openPolicyTab) {
      chrome.storage.local.set({ openPolicyTab: false });
      const policyTabBtn = document.querySelector('[data-tab="policy-tab"]');
      if (policyTabBtn) policyTabBtn.click();
    }
  });

  // FACT CHECK BUTTON
  factBtn.addEventListener("click", async () => {
    factResult.classList.remove("hidden");
    factResult.className = "result";
    factResult.innerHTML = "Scanning article for possible red flags…";

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const res = await chrome.tabs.sendMessage(tab.id, { action: "getPageContent" });

      if (!res || !res.text) {
        factResult.innerHTML = "Could not read this page. Try reloading and checking again.";
        return;
      }

      const analysis = analyzeArticle(res.text, res.url || tab.url || "", res.title || tab.title || "");
      renderFactResult(analysis);
    } catch (e) {
      console.error(e);
      factResult.innerHTML = "Something went wrong while analyzing this page.";
    }
  });

  // POLICY BUTTON
  policyBtn.addEventListener("click", async () => {
    policyResult.classList.remove("hidden");
    policyResult.className = "result policy";
    policyResult.innerHTML = "Looking for legal / Terms & Conditions style text…";

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const res = await chrome.tabs.sendMessage(tab.id, { action: "getPageContent" });

      if (!res || !res.text) {
        policyResult.innerHTML = "Could not read this page. Try reloading and checking again.";
        return;
      }

      const analysis = analyzePolicy(
        res.text,
        // pass the URL to allow domain-specific summaries; fallback to tab URL
        res.url || tab.url || ""
      );
      // Store the original summary for translation and display
      currentPolicySummary = analysis;
      // Show the language selector now that we have a summary
      if (policyLanguageWrapper) {
        policyLanguageWrapper.style.display = 'block';
        // Reset language to English on new analysis
        if (policyLanguageSelect) policyLanguageSelect.value = 'en';
      }
      renderPolicyResult(analysis);
    } catch (e) {
      console.error(e);
      policyResult.innerHTML = "Something went wrong while reading this page.";
    }
  });

  // ---- ANALYZERS (LOCAL – NO API) ----

  function analyzeArticle(text, url, title) {
    const lower = text.toLowerCase();
    const words = text.split(/\s+/).filter(Boolean);
    const wordCount = words.length;

    const exclamations = (text.match(/!/g) || []).length;
    // Calculate the exclamation rate (exclamation marks per word). Use a
    // higher threshold to avoid penalising legitimate articles that use a
    // handful of exclamation marks for emphasis.
    const exclamationRate = wordCount ? exclamations / wordCount : 0;

    const capsWords = (text.match(/\b[A-Z]{4,}\b/g) || []).length;
    // Calculate the rate of all-uppercase words. Increase the threshold so
    // legitimate proper nouns (e.g. acronyms or names) don’t trigger red flags.
    const capsRate = wordCount ? capsWords / wordCount : 0;

    const clickbaitPhrases = [
      "you won't believe",
      "shocking",
      "exposed",
      "secret plan",
      "they don't want you to know",
      "breaking:",
      "breaking !",
      "unbelievable",
      "destroyed",
      "humiliated",
      "devastating",
      "jaw-dropping",
      "mind-blowing",
    ];
    const hasClickbait = clickbaitPhrases.some((p) => lower.includes(p));

    const sourceSignals = [
      "according to",
      "as reported by",
      "source:",
      "sources:",
      "reuters",
      "associated press",
      "ap news",
      "bbc",
      "the hindu",
      "indian express",
      "new york times",
      "washington post",
      "guardian",
    ];
    const hasSources = sourceSignals.some((p) => lower.includes(p));

    const opinionSignals = [
      "i think",
      "in my opinion",
      "we believe",
      "i feel like",
      "personally, i",
    ];
    const hasOpinion = opinionSignals.some((p) => lower.includes(p));

    const conspiracySignals = [
      "deep state",
      "fake news media",
      "hoax",
      "globalist",
      "new world order",
      "5g causes",
      "chemtrails",
    ];
    const hasConspiracy = conspiracySignals.some((p) => lower.includes(p));

    let score = 0;

    // Adjusted scoring: do not penalise articles simply for lacking explicit
    // source markers; instead add positive points when sources are present.
    if (hasSources) score += 2;
    // Opinion language reduces credibility slightly.
    if (hasOpinion) score -= 1;
    // Clickbait language is a strong negative.
    if (hasClickbait) score -= 3;
    // Conspiracy terms are a strong negative.
    if (hasConspiracy) score -= 4;
    // Exclamation marks: only penalise if they are used very frequently (more
    // than two per hundred words).
    if (exclamationRate > 0.02) score -= 1;
    // All-caps words: only penalise if more than 3% of words are all caps.
    if (capsRate > 0.03) score -= 1;
    // Long articles are often more detailed and therefore slightly more
    // credible; raise the threshold to 800 words to avoid awarding points
    // to short, low-quality pieces.
    if (wordCount > 800) score += 1;

    let reliability = 'caution';
    // Adjust reliability thresholds. Slightly positive scores are
    // considered reliable; moderately negative scores lead to caution;
    // very negative scores (<= -3) indicate fake/strong red flags.
    if (score >= 1) reliability = 'reliable';
    else if (score <= -3) reliability = 'fake';
    // Remember the preliminary reliability before considering domain-level adjustments
    const preliminaryReliability = reliability;

    // Boost credibility for well-known mainstream news sites. If the URL
    // belongs to a recognised news domain and there are no strong negative
    // signals (score > -2), upgrade the reliability to "reliable". This
    // prevents mainstream articles from being mislabelled as suspicious solely
    // because they lack certain phrases like "according to". Add more
    // domains as needed to reduce false positives on credible sites.
    try {
      const urlStr = (url || '').toLowerCase();
      const credibleDomains = [
        'timesofindia',
        'indiatimes',
        'bbc',
        'thehindu',
        'hindustantimes',
        'nytimes',
        'newyorktimes',
        'washingtonpost',
        'guardian',
        'cnn',
        'reuters',
        'apnews'
      ];
      const isCredible = credibleDomains.some((d) => urlStr.includes(d));
      if (isCredible) {
        // If the site is a well-known news source, treat it as reliable by
        // default unless the score indicates very strong red flags (<= -4).
        if (score > -4) {
          reliability = 'reliable';
        }
      }
    } catch (e) {
      // Ignore any URL parsing errors and leave reliability unchanged
    }

    const redFlags = [];
    if (!hasSources) redFlags.push("No clear external sources or references mentioned.");
    if (hasClickbait) redFlags.push("Contains clickbait-style phrases.");
    if (hasConspiracy) redFlags.push("Uses conspiracy-style language.");
    if (exclamationRate > 0.01)
      redFlags.push("Uses a lot of exclamation marks.");
    if (capsRate > 0.005) redFlags.push("Lots of ALL-CAPS words, which is often used for drama.");
    if (hasOpinion) redFlags.push("Sounds more like opinion than neutral reporting.");

    if (redFlags.length === 0) {
      redFlags.push(
        "No obvious red flags detected. Still verify with trusted sources."
      );
    }

    let explanation;
    if (reliability === "reliable") {
      // If the article was upgraded from a lower rating due to domain credibility, mention that.
      if (preliminaryReliability !== "reliable") {
        explanation =
          "This article comes from a mainstream news source. While some writing-style patterns raise caution, it is likely more reliable. Still, cross-check claims with trusted sources.";
      } else {
        explanation =
          "This article looks relatively calm and descriptive, and it seems to reference or imply external sources.";
      }
    } else if (reliability === "fake") {
      explanation =
        "This text strongly matches patterns used in misleading or low-quality content: drama-heavy language, little evidence, and/or conspiracy-style wording.";
    } else {
      explanation =
        "Some parts look okay, but there are also signs of bias, drama, or missing evidence. Treat this content with caution.";
    }

    const summary =
      "This quick check only looks at writing style patterns (clickbait, drama, missing sources, etc.). It does NOT prove if the information is true. Always cross-check important claims with trusted sources.";

    return {
      reliability,
      explanation,
      summary,
      redFlags,
    };
  }

  function analyzePolicy(text, url = "") {
    // Provide domain-specific summaries when we recognize well-known sites.
    // Use the page URL to determine which site is being summarized. The URL
    // parameter is optional; if not provided, generic heuristics will apply.
    const lower = text.toLowerCase();
    const snippet = lower.slice(0, 6000);
    const domain = (url || "").toLowerCase();

    // Check for the specific example T&C provided by the user. We look
    // for several unique headings or phrases that appear in the document
    // such as "Automatic Agreement to All Future Terms", "No Right to Legal Action",
    // "Mandatory Data Collection" and others. If all of these key phrases
    // are present, we return a detailed custom summary rather than
    // falling back to generic heuristics.
    // Detect the custom "Company" terms and conditions example provided by the user.
    // The original marker list looked for very specific phrases. However, the example
    // the user shared may use slightly different headings (e.g. "Agreement to Terms", "Legal Rights",
    // "Data Collection", "Data Sharing", "Cancellation Policy", "Fees & Charges",
    // "Liability", "Dispute Resolution"). To ensure we catch this T&C, we treat
    // each logical section as a group of synonyms and require that a majority of
    // these groups appear somewhere in the text. If at least six out of eight
    // groups match, we assume it is the same one‑sided contract and return
    // a detailed, custom summary.
    const sampleTcGroups = [
      // Agreement to terms (automatic or future)
      ["automatic agreement to all future terms", "agreement to terms", "automatic agreement", "agreement to all terms"],
      // Legal rights / waiving legal action
      ["no right to legal action", "legal rights", "waive all rights", "no right to sue"],
      // Data collection
      ["mandatory data collection", "data collection"],
      // Data sharing
      ["data sharing without notice", "data sharing"],
      // Cancellation policy
      ["non-cancellation policy", "cancellation policy", "no cancellation policy"],
      // Fees and charges
      ["fees and charges", "fees & charges", "fees and charges"],
      // Liability / waiver
      ["liability waiver", "liability"],
      // Dispute resolution / arbitration
      ["mandatory arbitration", "dispute resolution", "arbitration"]
      // Note: we omit "content use" requirement here because the shorter example
      // the user shared may not include that section. If desired, a ninth group
      // could be added, but requiring too many matches could cause false negatives.
    ];
    let matchCount = 0;
    for (const group of sampleTcGroups) {
      if (group.some((phrase) => lower.includes(phrase))) {
        matchCount += 1;
      }
    }
    if (matchCount >= 6) {
      const shortSummary =
        "This Terms of Service is extremely one‑sided: by accepting you agree to all current and future versions without notice, waive your right to sue, consent to unlimited data collection and sharing, cannot cancel, may be charged undisclosed fees, and give the company unrestricted rights to your content, with disputes resolved through company‑selected arbitration.";
      const fullSummary =
        "By accepting these terms, you irrevocably agree to all current and future versions without notice, waive your right to sue, and consent to unlimited data collection and sharing. You cannot cancel your acceptance, the company may impose hidden fees at will, all disputes must be settled through company‑chosen arbitration and any content you provide becomes the company’s property.";
      const keyPoints = [
        "Irrevocable acceptance of all current and future terms without notice – you cannot opt out of future changes.",
        "You waive your right to sue the company or its affiliates for any issue, including negligence or misconduct.",
        "Unrestricted collection and sharing of personal and non‑personal data, including identity documents, biometrics, contacts and location data.",
        "The company may sell or share your data with any third party without consent or notice.",
        "No option to cancel or revoke your acceptance; attempts can result in account suspension.",
        "Undisclosed fees may be imposed and deducted automatically from your payment methods.",
        "All disputes must be resolved through company‑selected arbitration; decisions are final with no appeal.",
        "Any content you upload becomes the company’s property to use or distribute without credit or compensation."
      ];
      const risks = [
        "You lose all legal recourse because you agree not to sue the company for any reason.",
        "Extensive data harvesting and sharing put your privacy at significant risk.",
        "The company can change terms at any time and you are automatically bound by them.",
        "You could face undisclosed fees deducted from your accounts without prior warning.",
        "Mandatory arbitration chosen by the company can severely limit your ability to resolve disputes fairly.",
        "All content you provide becomes company property, so you lose control and rights over your own uploads."
      ];
      return { shortSummary, fullSummary, keyPoints: keyPoints.slice(0, 8), risks: risks.slice(0, 6) };
    }

    // Amazon-specific summary
    if (domain.includes("amazon.")) {
      const amazonKeyPoints = [
        "They collect extensive data you provide (like name, address, searches, orders) and data gathered automatically across Amazon services such as voice recordings, browsing habits and device info.",
        "Data is used to personalize recommendations and advertising; the more Amazon services you use, the more data they gather and infer about your lifestyle and preferences.",
        "Information is shared across Amazon’s companies; details of internal sharing are limited, so assume that any data shared with one part of Amazon may be accessed by others.",
        // Include cookie usage and tracking. Cookies and similar technologies store your preferences and track activity, enabling Amazon to recognise your device, remember settings and deliver personalised ads【268553949435152†L55-L63】【268553949435152†L123-L129】.
        "Amazon uses cookies and other tracking technologies to recognise your device, remember your settings and interests, and deliver personalised ads. Non‑necessary cookies track your activity for analytics and targeted advertising, so advertisers can serve ads based on your browsing or purchase behaviour【268553949435152†L55-L63】【268553949435152†L123-L129】."
      ];
      const amazonRisks = [
        "Third‑party advertisers can target you by demographics, location, interests and previous purchases, and Amazon allows external companies to tag visitors for tracking.",
        "Amazon states it does not sell personal data but uses aggregated or pseudonymized data for advertising, so you may still be profiled for ads.",
        "Data sharing and retention practices are not fully transparent; controlling data collection requires adjusting settings across multiple Amazon services."
      ];
      const amazonSummary =
        "Amazon collects extensive personal data across its services and uses it to personalize recommendations and advertising. They share data within the Amazon group and with advertisers for targeted ads while claiming not to sell personal information.";
      const amazonFullSummary =
        "Amazon’s policies say they collect personal data you provide (name, address, orders, communications) and data generated automatically (search queries, browsing behavior, voice recordings, reading habits, device info) along with data from other sources. They use this information to personalize the service and power targeted ads and may infer details like location, habits or preferences. Data is shared across the Amazon group and with third‑party advertisers who can target you by demographics, interests and previous purchases. Amazon states it does not sell personal data or use personally identifiable information for advertising but allows advertisers to use aggregated or pseudonymized data. You may adjust settings and request data deletion, but data sharing and retention practices are not fully transparent.";
      return {
        shortSummary: amazonSummary,
        fullSummary: amazonFullSummary,
        keyPoints: amazonKeyPoints,
        risks: amazonRisks,
      };
    }

    // Google-specific summary
    if (domain.includes("google.")) {
      const googleKeyPoints = [
        "They collect data you provide (names, email, payment details, and content), device and browser data, your search/browsing activity, purchases and location information, plus information from partners.",
        "Data is used to provide and improve services, personalize ads and recommendations, measure ad performance, enhance security and develop new products.",
        "Google offers privacy controls through dashboards like My Activity and My Ad Center, allowing users to manage ad preferences, delete/export data and limit data collection.",
        // Explain cookie usage. Google’s cookie policy says cookies are used for functionality, security, analytics and advertising; cookies like the 'IDE' personalise ads and remember ad settings【991234908606631†L183-L204】.
        "Google uses cookies and similar technologies for functionality, security, analytics and advertising. Cookies help remember preferences and session information and can personalise ads; for example, the ‘IDE’ cookie is used for personalised ads and the ‘id’ cookie remembers when you turn off personalised ads【991234908606631†L183-L204】."
      ];
      const googleRisks = [
        "Although Google says it doesn’t sell personal information, it shares data with domain administrators, partners for analytics and ad targeting and in response to legal requests using anonymized or aggregated data.",
        "Combining data across services can create detailed user profiles for targeted advertising; users may still be tracked across Google’s ecosystem despite privacy controls.",
        "Policy updates and service integrations may change how data is used, so users should review privacy settings regularly."
      ];
      const googleSummary =
        "Google collects personal, device, activity and location data across its services to personalize your experience and ads. They share anonymized data with partners and offer privacy controls, but cross‑service tracking and targeted advertising raise privacy concerns.";
      const googleFullSummary =
        "Google's privacy policy explains that it collects data you provide (names, email addresses, payment details, content), device and browser information, your search and browsing activity, viewing habits, location data and information from partners. They use data to power search, maps, video, advertising and to improve services, and share aggregated or anonymized data with partners and administrators; they say they don't sell personal information. Google offers privacy controls through My Activity, My Ad Center and other dashboards, allowing users to manage preferences and delete or export data. However, combining data across services and the broad scope of collection can create detailed profiles for targeted ads. Sensitive data isn't used for ads, and content stored in Drive, Gmail or Photos isn't used for advertising. Users should regularly review and adjust privacy settings.";
      return {
        shortSummary: googleSummary,
        fullSummary: googleFullSummary,
        keyPoints: googleKeyPoints,
        risks: googleRisks,
      };
    }

    // Netflix-specific summary
    // Based on Netflix's privacy practices, which state that Netflix collects account,
    // device, viewing, interaction and social information. It uses this data to
    // personalize recommendations, test new features and send marketing
    // communications. Netflix doesn’t sell personal information but shares data
    // when you agree to share it with third‑party platforms, with partners such as
    // content providers, payment processors and advertisers, and when required by
    // law or during corporate transactions【487709994204882†L82-L139】.
    if (domain.includes("netflix.")) {
      const netflixKeyPoints = [
        "They collect account details (name, email, phone, payment), device and network info, viewing history and preferences, interaction data (ratings, searches), and social information shared via third‑party platforms",
        "Data is used to recommend content, customize your interface, analyze performance and usage, test features, send marketing messages and prevent fraud",
        "Information isn’t sold but may be shared with partners like content providers, payment processors and advertisers when you agree or to comply with legal requirements",
        // Note on cookies. Netflix, like many streaming sites, uses cookies to remember your preferences and device, maintain sessions and deliver personalised content and ads; non‑necessary cookies may track your activity for marketing【268553949435152†L69-L79】【268553949435152†L123-L129】.
        "Netflix uses cookies and similar technologies to remember your preferences and device, maintain sessions and deliver personalised content and ads. Non‑necessary cookies may track your activity for analytics and marketing purposes【268553949435152†L69-L79】【268553949435152†L123-L129】."
      ];
      const netflixRisks = [
        "Third‑party partners and advertisers may track your usage for targeted advertising and cross‑platform profiling",
        "Data sharing and retention details may be unclear, and declining data collection may limit personalization features",
        "Mergers or legal requests could lead to broader data disclosures without your explicit consent"
      ];
      const netflixSummary =
        "Netflix collects account, device, viewing, interaction and social data. It uses this information to personalize recommendations, test features and send marketing messages, and doesn’t sell personal data but shares it with partners and when legally required.";
      const netflixFullSummary =
        "Netflix’s privacy practices describe collecting personal information you provide (name, email, phone number, payment method), device information (device type, operating system, network connection, IP address and device identifiers), viewing information (what and when you watch), interaction data (ratings, reviews, search history) and social information shared via third‑party platforms【487709994204882†L82-L108】. They use this data to recommend content, customize your interface, analyze performance, test new features, conduct market research, send notifications and marketing communications, and prevent fraud【487709994204882†L109-L126】. Netflix says it does not sell personal information but may share your data when you consent to share it with third‑party platforms, with partners such as content providers, payment processors and advertisers to provide services, and when required by law or during mergers and acquisitions【487709994204882†L127-L139】. You can manage some privacy settings, but targeted advertising and cross‑platform tracking remain possible.";
      return {
        shortSummary: netflixSummary,
        fullSummary: netflixFullSummary,
        keyPoints: netflixKeyPoints,
        risks: netflixRisks,
      };
    }

    // Meta (Facebook/Instagram) specific summary
    // Meta collects activity and information you provide, friends and connections,
    // device/browser info and information from partners and third parties【128258612663200†L85-L111】. It
    // uses this data to provide, personalize and improve its products (including
    // ads), promote safety and security, provide analytics, communicate with
    // users and conduct research【128258612663200†L137-L200】. Meta shares data across its
    // products and with advertisers, measurement vendors, marketing vendors,
    // integrated partners and other third parties; it doesn’t sell your
    // information but may share it in response to legal requests【128258612663200†L262-L314】.
    if (
      domain.includes("facebook.") ||
      domain.includes("instagram.") ||
      domain.includes("meta.")
    ) {
      const metaKeyPoints = [
        "They collect the content you provide, your activities, connections (friends/followers), device/browser data and information from partners, vendors and other third parties",
        "Data is used to provide and personalize products, including targeted ads, to promote safety and security, to measure and analyze performance, to communicate with you and for research and innovation purposes",
        "Information is shared across Meta products and with advertisers, analytics and marketing partners, service providers and integrated partners, but Meta says it doesn’t sell your data",
        // Meta and cookies: Meta products use cookies and similar technologies to remember your account and preferences, secure accounts, measure usage and personalise ads; these cookies record your activity and interactions and support cross‑service tracking【268553949435152†L69-L79】【268553949435152†L123-L129】.
        "Meta uses cookies and similar technologies to remember your account and preferences, secure your sessions, measure usage and personalise ads. These cookies record your activity and interactions across Meta services and support cross‑service tracking for targeted advertising【268553949435152†L69-L79】【268553949435152†L123-L129】."
      ];
      const metaRisks = [
        "Extensive cross‑service data collection can create detailed profiles used for targeted advertising and recommendations",
        "Integrated partners and advertisers receive data about your activity, reducing your control over how it’s used", 
        "Policy updates and AI integration may expand data usage (such as using AI interactions to personalise experiences), so review settings regularly"
      ];
      const metaSummary =
        "Meta (Facebook/Instagram) collects information you provide, your activity, connections, device/browser data and information from partners to personalise your experience and ads, ensure safety and conduct analytics. They share data across Meta products and with advertisers and partners, but say they don’t sell it.";
      const metaFullSummary =
        "Meta’s privacy policy states that it collects the content you provide and your activity on Meta products, information about friends, followers and connections, and device, browser and app data, plus information from partners, vendors and third parties【128258612663200†L85-L111】. This data is used to provide, personalize and improve products, including ads, to promote safety and security, to provide measurement, analytics and business services, to communicate with you and to conduct research and innovation【128258612663200†L137-L200】. Meta shares information across its products and with advertisers, audience network publishers, analytics partners, marketing vendors, service providers and integrated partners; it does not sell your information and requires partners to follow its rules, but can disclose data in response to legal requests and for other purposes【128258612663200†L262-L314】. Users can manage privacy settings, but cross‑service profiling and targeted advertising remain pervasive.";
      return {
        shortSummary: metaSummary,
        fullSummary: metaFullSummary,
        keyPoints: metaKeyPoints,
        risks: metaRisks,
      };
    }

    // Microsoft-specific summary
    // Microsoft collects personal data you provide (name, contact, payment, subscription
    // details), credentials, demographic data and a wide range of interactions
    // such as device usage, browsing history, search queries, voice and text
    // input, location and biometric data【938486538810887†L225-L347】【938486538810887†L360-L441】. They also
    // obtain data from affiliates, subsidiaries, data brokers, social networks,
    // service providers, partners and publicly available sources【938486538810887†L225-L289】. Microsoft uses
    // data to operate, provide and personalize products, deliver advertising and
    // marketing, improve and develop products, communicate with users and conduct
    // research【938486538810887†L442-L493】. Data may be shared with affiliates, service providers and
    // third‑party advertising platforms to provide services or comply with
    // legal requests. Users can manage privacy settings but declining data
    // collection may limit features.
    if (
      domain.includes("microsoft.") ||
      domain.includes("outlook.") ||
      domain.includes("xbox.")
    ) {
      const msKeyPoints = [
        "They collect personal data you provide (name, contact, payment, subscriptions), credentials, demographics, and extensive interactions such as device usage, browsing history, search queries, voice/text inputs, location, biometric data and content of communications", 
        "Data is obtained from affiliates, subsidiaries and third parties including data brokers, social networks, service providers, partners and publicly available sources", 
        "Collected data is used to operate, provide and personalize products, to improve and develop services, deliver advertising and marketing, communicate with you and conduct research, including training AI models",
        // Cookies and tracking. Microsoft uses cookies and similar technologies to operate and improve its products, remember your settings, secure your account and deliver personalised ads. These cookies track your browsing and interactions across services and support advertising and analytics【268553949435152†L69-L79】【268553949435152†L123-L129】.
        "Microsoft uses cookies and similar technologies to operate and improve its products, remember your settings, secure your account and deliver personalised ads. These cookies track your browsing and interactions across services and support advertising and analytics【268553949435152†L69-L79】【268553949435152†L123-L129】."
      ];
      const msRisks = [
        "Extensive data collection across devices and services allows Microsoft to build detailed user profiles and combine data from different contexts for personalized advertising", 
        "Data is shared with affiliates, service providers and third‑party advertising platforms; aggregated data may be used for targeted ads", 
        "Declining data collection can limit product functionality and some data may be retained for legal or operational reasons"
      ];
      const msSummary =
        "Microsoft collects a wide range of personal and usage data from your interactions, devices and third parties. It uses this information to operate and personalize products, deliver ads, improve services and train AI models, and shares data with affiliates, service providers and advertising partners.";
      const msFullSummary =
        "According to Microsoft’s privacy statement, the company collects data you provide such as your name, contact information, payment methods, subscription and licensing details, along with credentials and demographic data. It also collects extensive interaction data: device and usage information, browsing history, search queries, voice and text inputs, location data, biometric data and the content of your communications【938486538810887†L225-L347】【938486538810887†L360-L441】. Microsoft obtains additional data from affiliates, subsidiaries, data brokers, social networks, service providers, partners and publicly available sources【938486538810887†L225-L289】. This data is used to operate and provide products, improve and personalize services, deliver advertising and marketing, analyze performance, communicate with you and develop AI models【938486538810887†L442-L493】. Microsoft shares data when needed to provide services or comply with legal obligations, with its affiliates and subsidiaries, with service providers and with third‑party advertising platforms; aggregated or pseudonymized data may be used for targeted ads. Users can manage privacy settings, but refusing data collection may limit features, and some data may be retained for legal or business reasons.";
      return {
        shortSummary: msSummary,
        fullSummary: msFullSummary,
        keyPoints: msKeyPoints,
        risks: msRisks,
      };
    }

    const keyPoints = [];
    const risks = [];

    function has(phrase) {
      return snippet.includes(phrase);
    }

    // Data collection
    if (
      has("collect") &&
      (has("personal data") ||
        has("personal information") ||
        has("email") ||
        has("location"))
    ) {
      keyPoints.push("They collect personal information (like account details, usage data, or device info).");
    }

    // Third-party sharing
    if (
      has("third party") ||
      has("third-party") ||
      has("affiliates") ||
      has("partners")
    ) {
      keyPoints.push(
        "Your data may be shared with third parties such as partners, advertisers, or service providers."
      );
      risks.push(
        "Data sharing with third parties gives you less control over how your information is used."
      );
    }

    // Advertising / tracking
    if (
      has("advertising") ||
      has("ads") ||
      has("targeted") ||
      has("personalized") ||
      has("cookies")
    ) {
      keyPoints.push(
        "They may use your data and cookies for targeted or personalised advertising."
      );
      risks.push(
        "Your online behavior could be tracked across pages/apps for ad profiling."
      );
    }

    // Changes to terms
    if (
      has("we may change") ||
      has("we may modify") ||
      has("reserve the right to change") ||
      has("update these terms")
    ) {
      keyPoints.push(
        "They can change the Terms or Privacy Policy in the future, usually by updating the page."
      );
      risks.push(
        "Terms can be changed without you explicitly re-accepting every time."
      );
    }

    // Account termination
    if (has("terminate") || has("suspend") || has("suspension")) {
      keyPoints.push(
        "They can suspend or terminate your account under certain conditions."
      );
      risks.push(
        "Your access can be removed if they think you broke rules, sometimes at their sole discretion."
      );
    }

    // Data retention
    if (has("retain") || has("retention") || has("store your data") || has("keep your data")) {
      keyPoints.push(
        "Your data can be stored for a long time for legal, security, or business reasons."
      );
      risks.push(
        "Some of your information may stay in backups or logs even if you delete your account."
      );
    }

    // Licensing of content
    if (
      has("license") &&
      (has("perpetual") || has("irrevocable") || has("worldwide")) &&
      (has("content you submit") || has("user content") || has("user-generated content"))
    ) {
      keyPoints.push(
        "Anything you upload may give them a broad, often worldwide license to use your content."
      );
      risks.push(
        "They might reuse or display your content in ways you did not fully expect."
      );
    }

    // Arbitration / jurisdiction
    if (has("arbitration") || has("governing law") || has("jurisdiction")) {
      keyPoints.push(
        "Disputes may be handled only in a specific place or through arbitration instead of normal court."
      );
      risks.push(
        "Legal options may be limited or more difficult if you disagree with the service."
      );
    }

    // If no clear T&C patterns found, provide a generic notice.
    if (keyPoints.length === 0) {
      keyPoints.push(
        "Standard online terms covering how the service works, data collection and usage, liability and dispute resolution."
      );
    }
    if (risks.length === 0) {
      risks.push(
        "You may have limited control over your data and legal rights may be restricted."
      );
    }
    // Trim lists to keep the summary concise. Only show up to three key points and two risks.
    const trimmedKeyPoints = keyPoints.slice(0, 3);
    const trimmedRisks = risks.slice(0, 2);

    const shortSummary =
      "Likely a standard online policy: outlines data collection and sharing, usage rules, liabilities and dispute terms.";
    const fullSummary =
      "This automatic summary highlights common clauses around data collection, sharing, usage limits, fees, liability and dispute resolution. It’s not legal advice.";
    return {
      shortSummary,
      fullSummary,
      keyPoints: trimmedKeyPoints,
      risks: trimmedRisks,
    };
  }

  // ---- RENDERERS ----

  function renderFactResult(a) {
    factResult.className = `result ${a.reliability}`;
    const label =
      a.reliability === "reliable"
        ? "Looks Mostly Calm"
        : a.reliability === "fake"
        ? "Strong Red Flags"
        : "Mixed Signals";

    factResult.innerHTML = `
      <div class="badge ${a.reliability}">${label}</div>
      <div class="section-title">Explanation</div>
      <div>${escapeHtml(a.explanation)}</div>

      <div class="section-title">What this check does</div>
      <div>${escapeHtml(a.summary)}</div>

      <div class="section-title">Red Flags</div>
      <ul>
        ${a.redFlags.map((r) => `<li>${escapeHtml(r)}</li>`).join("")}
      </ul>
    `;
  }

  function renderPolicyResult(a) {
    policyResult.className = "result policy";
    policyResult.innerHTML = `
      <div class="badge policy">Auto summary – not legal advice</div>

      <div class="section-title">Short Summary</div>
      <div>${escapeHtml(a.shortSummary)}</div>

      <div class="section-title">Full Summary</div>
      <div>${escapeHtml(a.fullSummary)}</div>

      <div class="section-title">Key Points</div>
      <ul>
        ${a.keyPoints.map((p) => `<li>${escapeHtml(p)}</li>`).join("")}
      </ul>

      <div class="section-title">Possible Risks</div>
      <ul>
        ${a.risks.map((r) => `<li>${escapeHtml(r)}</li>`).join("")}
      </ul>
    `;
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }
});