chrome.runtime.onInstalled.addListener(() => {
  console.log("Check360 installed");
});

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.action === "openPopupWithPolicy") {
    chrome.storage.local.set({ openPolicyTab: true });
  }

  // Open a standalone summary page in a new tab. The content script will
  // already have stored the page text and metadata in chrome.storage.local.
  if (req.action === "openSummaryPage") {
    chrome.tabs.create({ url: chrome.runtime.getURL("summary.html") });
  }
});