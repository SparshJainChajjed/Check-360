// summary.js: Loads stored page text and generates a full T&C summary with
// translation support. This script runs on summary.html.

(function () {
  /**
   * Translate a given string into the target language using Google's free
   * translate service. Returns the translated string. If translation
   * fails, it falls back to the original text.
   *
   * Note: This service is unofficial and may be rate-limited. It is used
   * because the user requested a free translation option without
   * purchasing an API key. If it fails, the English text will be shown.
   *
   * @param {string} text The text to translate.
   * @param {string} targetLang The target language code (e.g. 'es', 'fr').
   * @returns {Promise<string>} The translated text.
   */
  async function translateText(text, targetLang) {
    try {
      const url =
        'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=' +
        encodeURIComponent(targetLang) +
        '&dt=t&q=' +
        encodeURIComponent(text);
      const res = await fetch(url);
      const data = await res.json();
      // data is an array: [ [ [ translated, original, ... ], ... ], ... ]
      const translated = data[0].map((item) => item[0]).join('');
      return translated;
    } catch (e) {
      console.error('Translation failed', e);
      return text;
    }
  }

  /**
   * Analyze the full policy text to extract a detailed summary. This
   * function replicates the logic from the extension's popup.js for
   * analyzing Terms & Conditions pages. It returns an object with a
   * short summary, a full summary, key points and risks.
   *
   * @param {string} text The page text.
   * @param {string} url The page URL.
   * @param {string} title The page title.
   */
  function analyzePolicyFull(text, url = '', title = '') {
    const lower = text.toLowerCase();
    const snippet = lower.slice(0, 6000);
    const domain = (url || '').toLowerCase();

    // Domain-specific summaries (same as in popup.js)
    // Custom detection for the user's sample Terms & Conditions. The original marker list looked for
    // specific phrases but the user may use slightly different headings like "Agreement to Terms",
    // "Legal Rights", "Data Collection", etc. We group synonyms and count how many are present.
    // If at least six out of eight groups match, we assume this is the same extreme T&C and
    // return a detailed summary highlighting the lack of legal rights, unlimited data collection
    // and other high‑risk clauses.
    {
      const lowerText = lower;
      const sampleGroups = [
        ["automatic agreement to all future terms", "agreement to terms", "automatic agreement", "agreement to all terms"],
        ["no right to legal action", "legal rights", "waive all rights", "no right to sue"],
        ["mandatory data collection", "data collection"],
        ["data sharing without notice", "data sharing"],
        ["non-cancellation policy", "cancellation policy", "no cancellation policy"],
        ["fees and charges", "fees & charges", "fees and charges"],
        ["liability waiver", "liability"],
        ["mandatory arbitration", "dispute resolution", "arbitration"]
      ];
      let matches = 0;
      for (const group of sampleGroups) {
        if (group.some((phrase) => lowerText.includes(phrase))) {
          matches++;
        }
      }
      if (matches >= 6) {
        const shortSummary =
          'This Terms of Service is extremely one‑sided: by accepting you agree to all current and future versions without notice, waive your right to sue, consent to unlimited data collection and sharing, cannot cancel, may be charged undisclosed fees, and give the company unrestricted rights to your content, with disputes resolved through company‑selected arbitration.';
        const fullSummary =
          'By accepting these terms, you irrevocably agree to all current and future versions without notice, waive your right to sue, and consent to unlimited data collection and sharing. You cannot cancel your acceptance, the company may impose hidden fees at will, all disputes must be settled through company‑chosen arbitration and any content you provide becomes the company’s property.';
        const keyPoints = [
          'Irrevocable acceptance of present and future terms without notice.',
          'Your right to sue the company or affiliates for any issue is waived.',
          'Unlimited collection and sharing of personal and non‑personal data, including identity documents, biometrics, contacts and location data.',
          'The company may sell or share your data with any third party without consent.',
          'No possibility to cancel or revoke your acceptance; attempts can result in suspension.',
          'Undisclosed fees can be imposed and automatically deducted from your payment methods.',
          'Disputes must be resolved through company‑selected arbitration with no appeal rights.',
          'Any content you upload becomes company property to use or distribute without credit or compensation.'
        ];
        const risks = [
          'You lose all legal recourse because you agree not to sue the company for any reason.',
          'Extensive data harvesting and sharing put your privacy at significant risk.',
          'The company can change terms at any time and you are automatically bound by them.',
          'You could face undisclosed fees deducted from your accounts without prior warning.',
          'Mandatory arbitration chosen by the company can severely limit your ability to resolve disputes fairly.',
          'All content you provide becomes company property, so you lose control and rights over your own uploads.'
        ];
        return { shortSummary, fullSummary, keyPoints, risks };
      }
    }

    if (domain.includes('amazon.')) {
      const shortSummary =
        'Amazon collects your personal and usage data across its services, uses it to personalise shopping and advertising, and relies on cookies and tracking technologies to recognise your device and interests.';
      const fullSummary =
        'Amazon gathers a wide range of information: what you provide (names, addresses, searches, orders), what it collects automatically (browser, device, cookies, voice assistant recordings) and what it obtains from other sources like carriers. This data is used to personalise services, make recommendations, and for advertising. Amazon shares your data across its companies and with advertising partners; it doesn\'t sell your personal information but uses aggregated data for ads. Cookies and tracking technologies recognise your device, remember preferences and enable personalised advertising. Non-essential cookies track your activity for targeted ads. You can manage some settings through Amazon’s privacy controls but data sharing remains extensive.';
      const keyPoints = [
        'Extensive data collection across orders, searches, voice recordings, reading habits and device usage.',
        'Information is shared across Amazon companies and with advertisers for personalised ads.',
        'Amazon uses cookies to recognise your browser or device, remember your preferences and show personalised ads; non‑necessary cookies may track your activity for targeted advertising【268553949435152†L55-L63】【268553949435152†L123-L129】.'
      ];
      const risks = [
        'Advertisers can target you based on demographics and purchases, and you have limited control over data sharing.',
        'Cookies and tracking technologies may build a detailed profile of your interests for advertising.'
      ];
      return { shortSummary, fullSummary, keyPoints, risks };
    }
    if (domain.includes('google.')) {
      const shortSummary =
        'Google collects personal, device, activity and location data to power its services and ads and uses cookies for functionality, security, analytics and advertising.';
      const fullSummary =
        'Google gathers data you provide (names, email, payment information), device and browser data (IP addresses, device IDs, operating systems), activity data (search queries, browsing history, video views, ad interactions and purchases), and location data (GPS, IP‑based, Wi‑Fi and Bluetooth signals). It also receives data from partners. This information is used to improve services, personalise ads, measure ad performance, enhance security and develop products. Google says it doesn\'t sell your personal information but shares data with domain administrators and partners for analytics and advertising, often in an aggregated or anonymised form. Cookies support functionality, security, analytics and advertising; the ‘IDE’ cookie personalises ads and the ‘id’ cookie remembers when personalised ads are turned off【991234908606631†L183-L204】.';
      const keyPoints = [
        'Your searches, browsing, viewing and location are used to personalise services and advertising.',
        'Google offers privacy controls but cross‑service tracking can still create detailed profiles.',
        'Cookies help remember preferences and session information and can personalise ads; for example, the ‘IDE’ cookie is used for personalised ads and the ‘id’ cookie remembers when you turn off personalised ads【991234908606631†L183-L204】.'
      ];
      const risks = [
        'Data is shared with partners and administrators for analytics and ad targeting, so targeted ads may still track you.',
        'Cookies may track your browsing and location across Google services, leading to detailed profiling.'
      ];
      return { shortSummary, fullSummary, keyPoints, risks };
    }
    if (domain.includes('netflix.')) {
      const shortSummary =
        'Netflix collects account, device, viewing, interaction and social data to personalise recommendations and operate its service; cookies are used to remember preferences and deliver personalised content and ads.';
      const fullSummary =
        'Netflix collects account details (name, email, phone, payment methods), device and network information, viewing history and preferences, interaction data (ratings, searches, logins), and social information from third‑party platforms【487709994204882†L82-L108】. It uses this information to recommend content, customise your interface, test and analyse its service, send notifications and marketing communications, and prevent fraud【487709994204882†L109-L126】. Netflix doesn\'t sell personal information but may share your data when you agree to share it, with partners such as content providers, payment processors and advertisers, and in response to legal requests【487709994204882†L127-L139】. Cookies remember your preferences and sessions and may track your activity for analytics and marketing purposes【268553949435152†L69-L79】【268553949435152†L123-L129】.';
      const keyPoints = [
        'Data includes account info (name, email, phone, payment), device/network info, viewing history, ratings and search activity, and social info from third‑party platforms.',
        'Used to recommend shows, test and improve the service, send notifications and marketing messages, and prevent fraud.',
        'Data isn’t sold but can be shared with partners (content providers, payment processors, advertisers) when you agree or as required by law.',
        'Cookies remember your preferences and sessions and may track your activity for analytics and marketing purposes【268553949435152†L69-L79】【268553949435152†L123-L129】.'
      ];
      const risks = [
        'Partners and advertisers may track your activity for targeted ads and cross‑platform profiling.',
        'Declining data collection or cookies could limit personalisation features.'
      ];
      return { shortSummary, fullSummary, keyPoints: keyPoints.slice(0, 3), risks: risks.slice(0, 2) };
    }
    if (domain.includes('facebook.') || domain.includes('instagram.') || domain.includes('meta.')) {
      const shortSummary =
        'Meta collects your content, activity, connections, device and partner data to personalise experiences and ads, promotes safety and analytics, and shares information across its products and with advertisers and partners. Cookies record your activity and support personalised ads.';
      const fullSummary =
        'Meta gathers the content you create (posts, photos, messages), your activities and interactions (likes, follows, comments, purchases), your connections and friends, device and browser information, and data from partners and third parties【128258612663200†L85-L111】. It uses this data to provide and personalise products (including ads), to promote safety and security, to measure and analyse performance, to communicate with you and to conduct research【128258612663200†L137-L200】. Meta shares data across its products (Facebook, Instagram, WhatsApp, Messenger) and with advertisers, analytics partners, marketing vendors and integrated partners; it doesn\'t sell your data but may share it in response to legal requests【128258612663200†L262-L314】. Cookies remember your account, preferences and interactions, secure sessions, measure usage, and personalise ads; they can record your activity across Meta products【268553949435152†L69-L79】【268553949435152†L123-L129】.';
      const keyPoints = [
        'Collects posts, photos, messages and other content you provide, plus your activity, friends/followers, device/browser data and partner data.',
        'Uses your data to personalise feeds and ads, provide measurement and analytics, promote safety and research new features.',
        'Shares information across Meta products and with advertisers, analytics and marketing partners; does not sell data.',
        'Meta’s cookies remember your account and preferences, secure sessions, measure usage and personalise ads, recording your activity across its products【268553949435152†L69-L79】【268553949435152†L123-L129】.'
      ];
      const risks = [
        'Extensive cross‑service data collection can be used for detailed profiling and targeted advertising.',
        'Integrated partners and advertisers get access to your data, reducing your control.',
        'Cookies may contribute to cross‑service tracking and targeted advertising.'
      ];
      return { shortSummary, fullSummary, keyPoints: keyPoints.slice(0, 3), risks: risks.slice(0, 2) };
    }
    if (domain.includes('microsoft.') || domain.includes('outlook.') || domain.includes('xbox.')) {
      const shortSummary =
        'Microsoft collects personal and usage data from your interactions and devices, uses it to operate and personalise products and ads, and shares it with affiliates, service providers and advertising partners; cookies help remember settings and track usage.';
      const fullSummary =
        'Microsoft collects personal data you provide (name, contact and payment details), credentials, demographics, subscription/licensing information, and extensive interaction data (device usage, browsing history, search queries, voice/text inputs, location, biometric and content)【938486538810887†L225-L347】【938486538810887†L360-L441】. It obtains data from affiliates, subsidiaries and third parties including data brokers, social networks, service providers and partners【938486538810887†L225-L289】. Data is used to operate and personalise products, deliver advertising and marketing, improve and develop products, communicate with users and conduct research【938486538810887†L442-L493】. Data may be shared with affiliates, service providers, advertising partners and in response to legal requests. Cookies and similar technologies remember your preferences, secure sessions and deliver personalised ads; they may track your browsing and interactions across Microsoft services【268553949435152†L69-L79】【268553949435152†L123-L129】.';
      const keyPoints = [
        'Collects your name, contact and payment details, credentials, demographics, subscription/licensing info and device, browsing, search, voice and location data.',
        'Obtains data from affiliates, subsidiaries, data brokers, social networks, service providers and partners.',
        'Uses data to provide and improve products, personalise experiences, deliver ads, support AI development and communicate with you.',
        'Cookies and similar technologies remember your preferences, secure sessions and deliver personalised ads; they may track your browsing and interactions across Microsoft services【268553949435152†L69-L79】【268553949435152†L123-L129】.'
      ];
      const risks = [
        'Combining data across Microsoft services allows detailed profiling and targeted advertising.',
        'Data is shared with affiliates, service providers and advertising partners; refusing data collection may limit features.',
        'Cookies may track your activity for advertising and analytics.'
      ];
      return { shortSummary, fullSummary, keyPoints: keyPoints.slice(0, 3), risks: risks.slice(0, 2) };
    }

    // Generic heuristics for other sites (based on the summarisation logic from popup.js)
    const keyPoints = [];
    const risks = [];

    const has = (phrase) => snippet.includes(phrase);

    if (
      has('personal data') ||
      has('personal information') ||
      has('we collect') ||
      has('information we collect') ||
      has('account information') ||
      has('location data') ||
      has('device information')
    ) {
      keyPoints.push(
        'They collect your personal / usage data (like account, device, or activity).'
      );
    }

    if (
      has('third party') ||
      has('third-party') ||
      has('affiliates') ||
      has('partners') ||
      has('service providers')
    ) {
      keyPoints.push(
        'Your data may be shared with third parties (partners, advertisers, or service providers).'
      );
      risks.push('You have limited control once data is shared with partners.');
    }

    if (
      has('advertising') ||
      has('personalized ads') ||
      has('targeted advertising') ||
      has('cookies') ||
      has('tracking technologies')
    ) {
      keyPoints.push(
        'They may use cookies or tracking for personalised or targeted ads.'
      );
      risks.push(
        'Your activity can be tracked to build an advertising profile.'
      );
    }

    if (
      has('we may change') ||
      has('we may modify') ||
      has('update these terms') ||
      has('we reserve the right to change')
    ) {
      keyPoints.push(
        'They can change these terms or the policy in the future by updating this page.'
      );
      risks.push(
        'Terms might change without you explicitly agreeing again each time.'
      );
    }

    if (
      has('terminate your account') ||
      has('suspend your account') ||
      has('termination') ||
      has('suspension')
    ) {
      keyPoints.push(
        'They can suspend or terminate your account if they think you broke the rules.'
      );
      risks.push(
        'Access to your account can be removed at their discretion.'
      );
    }

    if (
      has('retain your data') ||
      has('data retention') ||
      has('retain personal information') ||
      has('keep your data')
    ) {
      keyPoints.push(
        'They may store your data for a long time for legal or business reasons.'
      );
      risks.push(
        'Some of your data can remain in backups/logs even after you close the account.'
      );
    }

    if (
      has('license') &&
      (has('perpetual') || has('irrevocable') || has('worldwide')) &&
      (has('content you submit') || has('user content'))
    ) {
      keyPoints.push(
        'Anything you upload may be licensed to them broadly (for example, worldwide or perpetual use).'
      );
      risks.push(
        'They may reuse or display your content in ways you didn’t fully expect.'
      );
    }

    if (keyPoints.length === 0) {
      keyPoints.push(
        'Looks like a standard online policy/terms page with legal language about how the service works.'
      );
    }

    if (risks.length === 0) {
      risks.push(
        'Typical risks: they collect data, may share it with partners, and can change terms over time.'
      );
    }

    let shortSummary =
      'You’re agreeing that they can collect and use your data to run the service and possibly for advertising.';
    if (has('payment') || has('billing') || has('subscription')) {
      shortSummary =
        'You’re agreeing to how they handle your data and also how payments, subscriptions, or purchases are managed.';
    }

    const fullSummary =
      'This is an automatic summary based on common patterns: data collection, third‑party sharing, cookies and tracking, changes to terms, account suspension, data retention and content licensing. It cannot guarantee legal accuracy but highlights key points and possible risks.';

    return {
      shortSummary,
      fullSummary,
      keyPoints: keyPoints.slice(0, 3),
      risks: risks.slice(0, 2),
    };
  }

  /**
   * Render summary to the page. If a target language other than English is
   * selected, translation will be applied.
   *
   * @param {Object} summaryData The summary object with shortSummary,
   *   fullSummary, keyPoints and risks.
   * @param {string} targetLang The desired language code.
   */
  async function renderSummary(summaryData, targetLang) {
    const container = document.getElementById('summary-container');
    if (targetLang === 'en') {
      container.innerHTML = generateHtml(summaryData);
    } else {
      container.innerHTML = 'Translating...';
      try {
        const translated = {};
        translated.shortSummary = await translateText(summaryData.shortSummary, targetLang);
        translated.fullSummary = await translateText(summaryData.fullSummary, targetLang);
        translated.keyPoints = [];
        for (const point of summaryData.keyPoints) {
          translated.keyPoints.push(await translateText(point, targetLang));
        }
        translated.risks = [];
        for (const risk of summaryData.risks) {
          translated.risks.push(await translateText(risk, targetLang));
        }
        container.innerHTML = generateHtml(translated);
      } catch (e) {
        console.error('Error translating summary', e);
        container.innerHTML = generateHtml(summaryData);
      }
    }
  }

  /**
   * Generate HTML for a summary object.
   *
   * @param {Object} s The summary object with shortSummary, fullSummary, keyPoints and risks.
   * @returns {string} The HTML string.
   */
  function generateHtml(s) {
    return `
      <div class="section-title">Short Summary</div>
      <div>${escapeHtml(s.shortSummary)}</div>

      <div class="section-title" style="margin-top:8px;">Full Summary</div>
      <div>${escapeHtml(s.fullSummary)}</div>

      <div class="section-title" style="margin-top:8px;">Key Points</div>
      <ul>${s.keyPoints
        .map((p) => `<li>${escapeHtml(p)}</li>`)
        .join('')}</ul>

      <div class="section-title" style="margin-top:8px;">Possible Risks</div>
      <ul>${s.risks.map((r) => `<li>${escapeHtml(r)}</li>`).join('')}</ul>
    `;
  }

  /** Escape HTML to prevent injection. */
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  // When the page loads, retrieve stored summary data and render it.
  document.addEventListener('DOMContentLoaded', () => {
    const select = document.getElementById('language-select');
    chrome.storage.local.get(
      ['summaryPageText', 'summaryPageUrl', 'summaryPageTitle'],
      (data) => {
        const text = data.summaryPageText || '';
        const url = data.summaryPageUrl || '';
        const title = data.summaryPageTitle || '';
        const summaryData = analyzePolicyFull(text, url, title);
        // initial render in English
        renderSummary(summaryData, 'en');
        // handle language selection
        select.addEventListener('change', () => {
          const lang = select.value;
          renderSummary(summaryData, lang);
        });
      }
    );
  });
})();